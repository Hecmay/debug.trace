//Numpy array shape [5]
//Min -0.132971197367
//Max 0.070498652756
//Number of zeros 0

#ifndef B11_H_
#define B11_H_

#ifndef __SYNTHESIS__
model_default_t b11[5];
#else
model_default_t b11[5] = {-0.1329711974, 0.0704986528, 0.0541036762, 0.0108017856, -0.0186436363};
#endif

#endif
